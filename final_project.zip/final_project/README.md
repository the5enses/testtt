# NODE_PROJECT
Online Shoe Store

This project contains three main features.
1. Account creation and verification
2. Connection to database to pull shoe 
    information into the shop page.
3. The ability to add items/remove into a shopping
    cart and persist for the user account.
     